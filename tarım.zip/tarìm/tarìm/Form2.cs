﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarım
{
    public partial class Form2 : Form
    {
        private List<string> crops = new List<string>();
        public Form2()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            btnCrops.Enabled = false;
            btnAddCrop.Enabled = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void txtCropType_TextChanged(object sender, EventArgs e)
        {
            UpdateButtonsState();
        }

        private void txtPlantingDate_TextChanged(object sender, EventArgs e)
        {
            UpdateButtonsState();
        }

        private void txtHarvestDate_TextChanged(object sender, EventArgs e)
        {
            UpdateButtonsState();
        }

        private void UpdateButtonsState()
        {
            string CropType = txtCropType.Text;
            string PlantingDate = txtPlantingDate.Text;
            string HarvestDate = txtHarvestDate.Text;
            btnAddCrop.Enabled = !string.IsNullOrWhiteSpace(CropType) && !string.IsNullOrWhiteSpace(PlantingDate) && !string.IsNullOrWhiteSpace(HarvestDate);
        }

        private void btnAddCrop_Click(object sender, EventArgs e)
        {
            string cropType = txtCropType.Text;
            string plantingDate = txtPlantingDate.Text;
            string harvestDate = txtHarvestDate.Text;

            string cropInfo = $"Mahsul: {cropType}, Ekim Tarihi: {plantingDate}, Hasat Tarihi: {harvestDate}";
            crops.Add(cropInfo);
            lstCrops.Items.Clear();
            foreach (string crop in crops)
            {
                lstCrops.Items.Add(crop);
            }
            MessageBox.Show("Mahsul eklendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lstCrops_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblCropStatus_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }

        private void btnCrops_Click(object sender, EventArgs e)
        {

        }

        private void btnIrrigation_Click(object sender, EventArgs e)
        {
            this.Hide();
            Water irrigationForm = new Water();
            irrigationForm.Show();
        }

        private void btnFertilization_Click(object sender, EventArgs e)
        {
            this.Hide();
            FertilizationForm fertilizationForm = new FertilizationForm();
            fertilizationForm.Show();
        }
    }
}
