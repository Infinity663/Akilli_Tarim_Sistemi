﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarım
{
    public partial class FertilizationForm : Form
    {
        private bool isManualFertilizing = false;
        private bool isTimerRunning = true;
        public FertilizationForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            btnFertilization.Enabled = false;
            timerAutoFertilization.Interval = 1000;
            timerAutoFertilization.Tick += TimerAutoFertilization_Tick;
            timerAutoFertilization.Start();
            btnManualFertilization.Click += btnManualFertilization_Click;
            btnStopTimer.Click += btnStopTimer_Click;
            BtnStartTimer.Enabled = false;
        }
        
        private void FertilizationForm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }

        private void btnCrops_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void btnIrrigation_Click(object sender, EventArgs e)
        {
            this.Hide();
            Water irrigationForm = new Water();
            irrigationForm.Show();
        }

        private void btnFertilization_Click(object sender, EventArgs e)
        {

        }

        private void btnManualFertilization_Click(object sender, EventArgs e)
        {
            isManualFertilizing = true;
            MessageBox.Show("Manuel gübreleme ve ilaçlama yapıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnStopTimer_Click(object sender, EventArgs e)
        {
            isTimerRunning = false;
            timerAutoFertilization.Stop();           
            btnStopTimer.Enabled = false;
            BtnStartTimer.Enabled = true;
            label1.Text = "Gübreleme ve İlaçlama Zamanlayıcısı Kapalı";
            label2.Text = "Otomatik gübreleme ve ilaçlama yapılmayacaktır.";
            MessageBox.Show("Zamanlayıcı kapalı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void TimerAutoFertilization_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            int month = now.Month;

            if ((month == 4 || month == 9) && !isManualFertilizing && isTimerRunning)
            {
                MessageBox.Show("Otomatik gübreleme ve ilaçlama yapıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnStartTimer_Click(object sender, EventArgs e)
        {
            isTimerRunning = true;
            timerAutoFertilization.Start();            
            btnStopTimer.Enabled = true;
            BtnStartTimer.Enabled = false;
            label1.Text = "Gübreleme ve İlaçlama Zamanlayıcısı Açık";
            label2.Text = "Nisan ve Eylül aylarında otomatik gübreleme ve ilaçlama yapılacaktır.";
            MessageBox.Show("Zamanlayıcı açık.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
