﻿namespace tarım
{
    partial class FertilizationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFertilization = new System.Windows.Forms.Button();
            this.btnIrrigation = new System.Windows.Forms.Button();
            this.btnCrops = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnManualFertilization = new System.Windows.Forms.Button();
            this.timerAutoFertilization = new System.Windows.Forms.Timer(this.components);
            this.btnStopTimer = new System.Windows.Forms.Button();
            this.BtnStartTimer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnFertilization
            // 
            this.btnFertilization.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnFertilization.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFertilization.Location = new System.Drawing.Point(10, 127);
            this.btnFertilization.Name = "btnFertilization";
            this.btnFertilization.Size = new System.Drawing.Size(88, 39);
            this.btnFertilization.TabIndex = 34;
            this.btnFertilization.Text = "Gübreleme ve İlaçlama";
            this.btnFertilization.UseVisualStyleBackColor = false;
            this.btnFertilization.Click += new System.EventHandler(this.btnFertilization_Click);
            // 
            // btnIrrigation
            // 
            this.btnIrrigation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnIrrigation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrrigation.Location = new System.Drawing.Point(12, 85);
            this.btnIrrigation.Name = "btnIrrigation";
            this.btnIrrigation.Size = new System.Drawing.Size(86, 36);
            this.btnIrrigation.TabIndex = 33;
            this.btnIrrigation.Text = "Sulama";
            this.btnIrrigation.UseVisualStyleBackColor = false;
            this.btnIrrigation.Click += new System.EventHandler(this.btnIrrigation_Click);
            // 
            // btnCrops
            // 
            this.btnCrops.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnCrops.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCrops.Location = new System.Drawing.Point(12, 41);
            this.btnCrops.Name = "btnCrops";
            this.btnCrops.Size = new System.Drawing.Size(86, 36);
            this.btnCrops.TabIndex = 32;
            this.btnCrops.Text = "Mahsul";
            this.btnCrops.UseVisualStyleBackColor = false;
            this.btnCrops.Click += new System.EventHandler(this.btnCrops_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(54, 23);
            this.btnBack.TabIndex = 31;
            this.btnBack.Text = "< Geri";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click_1);
            // 
            // btnManualFertilization
            // 
            this.btnManualFertilization.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnManualFertilization.Location = new System.Drawing.Point(539, 326);
            this.btnManualFertilization.Name = "btnManualFertilization";
            this.btnManualFertilization.Size = new System.Drawing.Size(114, 23);
            this.btnManualFertilization.TabIndex = 35;
            this.btnManualFertilization.Text = "Gübrele ve İlaçla";
            this.btnManualFertilization.UseVisualStyleBackColor = true;
            this.btnManualFertilization.Click += new System.EventHandler(this.btnManualFertilization_Click);
            // 
            // btnStopTimer
            // 
            this.btnStopTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnStopTimer.ForeColor = System.Drawing.Color.DarkRed;
            this.btnStopTimer.Location = new System.Drawing.Point(471, 188);
            this.btnStopTimer.Name = "btnStopTimer";
            this.btnStopTimer.Size = new System.Drawing.Size(146, 39);
            this.btnStopTimer.TabIndex = 37;
            this.btnStopTimer.Text = "Zamanlayıcıyı Kapa";
            this.btnStopTimer.UseVisualStyleBackColor = true;
            this.btnStopTimer.Click += new System.EventHandler(this.btnStopTimer_Click);
            // 
            // BtnStartTimer
            // 
            this.BtnStartTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnStartTimer.ForeColor = System.Drawing.Color.DarkGreen;
            this.BtnStartTimer.Location = new System.Drawing.Point(307, 188);
            this.BtnStartTimer.Name = "BtnStartTimer";
            this.BtnStartTimer.Size = new System.Drawing.Size(146, 39);
            this.BtnStartTimer.TabIndex = 38;
            this.BtnStartTimer.Text = "Zamanlayıcıyı Aç";
            this.BtnStartTimer.UseVisualStyleBackColor = true;
            this.BtnStartTimer.Click += new System.EventHandler(this.BtnStartTimer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(256, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(415, 25);
            this.label1.TabIndex = 39;
            this.label1.Text = "Gübreleme ve İlaçlama Zamanlayıcısı Açık";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(272, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(381, 15);
            this.label2.TabIndex = 40;
            this.label2.Text = "Nisan ve Eylül aylarında otomatik gübreleme ve ilaçlama yapılacaktır.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(258, 329);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(275, 15);
            this.label3.TabIndex = 41;
            this.label3.Text = "Şu anda da gübreleme ve ilaçlama yapabilirsiniz:";
            // 
            // FertilizationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnStartTimer);
            this.Controls.Add(this.btnStopTimer);
            this.Controls.Add(this.btnManualFertilization);
            this.Controls.Add(this.btnFertilization);
            this.Controls.Add(this.btnIrrigation);
            this.Controls.Add(this.btnCrops);
            this.Controls.Add(this.btnBack);
            this.Name = "FertilizationForm";
            this.Text = "Gübreleme ve İlaçlama";
            this.Load += new System.EventHandler(this.FertilizationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFertilization;
        private System.Windows.Forms.Button btnIrrigation;
        private System.Windows.Forms.Button btnCrops;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnManualFertilization;
        private System.Windows.Forms.Timer timerAutoFertilization;
        private System.Windows.Forms.Button btnStopTimer;
        private System.Windows.Forms.Button BtnStartTimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}