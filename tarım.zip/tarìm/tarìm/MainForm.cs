﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarım
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnCrops_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
            
        }

        private void btnIrrigation_Click(object sender, EventArgs e)
        {
            this.Hide();
            Water irrigationForm = new Water();
            irrigationForm.Show();
            

        }

        private void btnFertilization_Click(object sender, EventArgs e)
        {
            this.Hide();
            FertilizationForm fertilizationForm = new FertilizationForm();
            fertilizationForm.Show();
            
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
