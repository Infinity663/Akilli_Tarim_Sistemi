﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace tarım
{
    public partial class Water : Form
    {
        private bool isIrrigating = false;
        private int soilMoisture = 38;

        public Water()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            btnIrrigationn.Enabled = false;
            btnStopIrrigation.Enabled = false;
            timer1.Start();
        }

        private void btnStopIrrigation_Click(object sender, EventArgs e)
        {
            isIrrigating = false;
            label2.Text = $"Sulama: Kapalı";
            label2.ForeColor = Color.DarkRed;
            btnStartIrrigation.Enabled = true;
            btnStopIrrigation.Enabled = false;
        }

        private void btnStartIrrigation_Click(object sender, EventArgs e)
        {
            isIrrigating = true;
            label2.Text = $"Sulama: Açık";
            label2.ForeColor = Color.DarkGreen;
            btnStartIrrigation.Enabled = false;
            btnStopIrrigation.Enabled = true;
        }

        private void lblSoilMoisture_Click(object sender, EventArgs e)
        {

        }

        private void Water_Load(object sender, EventArgs e)
        {
            lblSoilMoisture.Text = $"Toprak Nem Sensörü: {soilMoisture}%";
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isIrrigating)
            {
                if (soilMoisture < 100)
                {
                    soilMoisture += 2;
                }
                else
                {
                    btnStopIrrigation_Click(null, null);
                }
            }
            else
            {
                if (soilMoisture > 25)
                {
                    soilMoisture -= 1;
                }
                else
                {
                    btnStartIrrigation_Click(null, null);
                }
            }

            lblSoilMoisture.Text = $"Toprak Nem Sensörü: {soilMoisture}%";
        }

        private void btnCrops_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.Show();
            this.Hide();
        }

        private void btnIrrigationn_Click(object sender, EventArgs e)
        {

        }

        private void btnFertilizationn_Click(object sender, EventArgs e)
        {
            this.Hide();
            FertilizationForm fertilizationForm = new FertilizationForm();
            fertilizationForm.Show();
        }

        private void lblSoilMoisture_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }
    }
}
