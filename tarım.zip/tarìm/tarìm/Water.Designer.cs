﻿namespace tarım
{
    partial class Water
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblSoilMoisture;
        private System.Windows.Forms.Button btnStartIrrigation;
        private System.Windows.Forms.Button btnStopIrrigation;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblSoilMoisture = new System.Windows.Forms.Label();
            this.btnStartIrrigation = new System.Windows.Forms.Button();
            this.btnStopIrrigation = new System.Windows.Forms.Button();
            this.btnFertilizationn = new System.Windows.Forms.Button();
            this.btnIrrigationn = new System.Windows.Forms.Button();
            this.btnCrops = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lblSoilMoisture
            // 
            this.lblSoilMoisture.AutoSize = true;
            this.lblSoilMoisture.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblSoilMoisture.Location = new System.Drawing.Point(303, 127);
            this.lblSoilMoisture.Name = "lblSoilMoisture";
            this.lblSoilMoisture.Size = new System.Drawing.Size(224, 26);
            this.lblSoilMoisture.TabIndex = 0;
            this.lblSoilMoisture.Text = "Toprak Nem Sensörü:";
            this.lblSoilMoisture.Click += new System.EventHandler(this.lblSoilMoisture_Click_1);
            // 
            // btnStartIrrigation
            // 
            this.btnStartIrrigation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnStartIrrigation.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnStartIrrigation.Location = new System.Drawing.Point(307, 217);
            this.btnStartIrrigation.Name = "btnStartIrrigation";
            this.btnStartIrrigation.Size = new System.Drawing.Size(132, 31);
            this.btnStartIrrigation.TabIndex = 1;
            this.btnStartIrrigation.Text = "Sulamayı Başlat";
            this.btnStartIrrigation.UseVisualStyleBackColor = true;
            this.btnStartIrrigation.Click += new System.EventHandler(this.btnStartIrrigation_Click);
            // 
            // btnStopIrrigation
            // 
            this.btnStopIrrigation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnStopIrrigation.ForeColor = System.Drawing.Color.DarkRed;
            this.btnStopIrrigation.Location = new System.Drawing.Point(445, 217);
            this.btnStopIrrigation.Name = "btnStopIrrigation";
            this.btnStopIrrigation.Size = new System.Drawing.Size(132, 31);
            this.btnStopIrrigation.TabIndex = 2;
            this.btnStopIrrigation.Text = "Sulamayı Durdur";
            this.btnStopIrrigation.UseVisualStyleBackColor = true;
            this.btnStopIrrigation.Click += new System.EventHandler(this.btnStopIrrigation_Click);
            // 
            // btnFertilizationn
            // 
            this.btnFertilizationn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnFertilizationn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFertilizationn.Location = new System.Drawing.Point(10, 127);
            this.btnFertilizationn.Name = "btnFertilizationn";
            this.btnFertilizationn.Size = new System.Drawing.Size(88, 40);
            this.btnFertilizationn.TabIndex = 29;
            this.btnFertilizationn.Text = "Gübreleme ve İlaçlama";
            this.btnFertilizationn.UseVisualStyleBackColor = false;
            this.btnFertilizationn.Click += new System.EventHandler(this.btnFertilizationn_Click);
            // 
            // btnIrrigationn
            // 
            this.btnIrrigationn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnIrrigationn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIrrigationn.Location = new System.Drawing.Point(12, 85);
            this.btnIrrigationn.Name = "btnIrrigationn";
            this.btnIrrigationn.Size = new System.Drawing.Size(86, 36);
            this.btnIrrigationn.TabIndex = 28;
            this.btnIrrigationn.Text = "Sulama";
            this.btnIrrigationn.UseVisualStyleBackColor = false;
            this.btnIrrigationn.Click += new System.EventHandler(this.btnIrrigationn_Click);
            // 
            // btnCrops
            // 
            this.btnCrops.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnCrops.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCrops.Location = new System.Drawing.Point(12, 41);
            this.btnCrops.Name = "btnCrops";
            this.btnCrops.Size = new System.Drawing.Size(86, 36);
            this.btnCrops.TabIndex = 27;
            this.btnCrops.Text = "Mahsul";
            this.btnCrops.UseVisualStyleBackColor = false;
            this.btnCrops.Click += new System.EventHandler(this.btnCrops_Click_1);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(54, 23);
            this.btnBack.TabIndex = 26;
            this.btnBack.Text = "< Geri";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(305, 370);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 17);
            this.label1.TabIndex = 30;
            this.label1.Text = "Not: Otomatik de başlayıp durmaktadır.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(390, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 17);
            this.label2.TabIndex = 31;
            this.label2.Text = "Sulama: Kapalı";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Water
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFertilizationn);
            this.Controls.Add(this.btnIrrigationn);
            this.Controls.Add(this.btnCrops);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnStopIrrigation);
            this.Controls.Add(this.btnStartIrrigation);
            this.Controls.Add(this.lblSoilMoisture);
            this.Name = "Water";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sulama";
            this.Load += new System.EventHandler(this.Water_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button btnFertilizationn;
        private System.Windows.Forms.Button btnIrrigationn;
        private System.Windows.Forms.Button btnCrops;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
