﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace tarım
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string> users = new Dictionary<string, string>();
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            btnRegister.Enabled = false;
            btnLogin.Enabled = false;
            txtPassword.PasswordChar = '*';

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            UpdateButtonsState();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            UpdateButtonsState();
        }

        private void UpdateButtonsState()
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            btnRegister.Enabled = !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password);
            btnLogin.Enabled = !string.IsNullOrWhiteSpace(username) && !string.IsNullOrWhiteSpace(password);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (users.ContainsKey(username) && users[username] == password)
            {

                MainForm mainform = new MainForm();
                mainform.FormClosed += MainForm_FormClosed;
                mainform.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre yanlış.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (!users.ContainsKey(username))
            {
                users.Add(username, password);
                MessageBox.Show("Kayıt başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Kullanıcı zaten mevcut.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
